rm -rf doc
rdoc bin lib
